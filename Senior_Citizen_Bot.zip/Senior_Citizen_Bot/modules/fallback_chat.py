def simple_chat(query):
    query = query.lower()
    if "hello" in query or "hi" in query:
        return "Hello! How can I assist you today?"
    elif "how are you" in query:
        return "I'm just a bot, but I'm doing great!"
    else:
        return "I'm sorry, I don't understand that yet."
