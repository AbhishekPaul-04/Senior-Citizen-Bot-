import requests
from api_keys.api_keys import NEWSDATA_API_KEY

def get_news():
    try:
        url = f"https://newsdata.io/api/1/news?apikey={NEWSDATA_API_KEY}&country=in&language=en"
        response = requests.get(url).json()
        articles = response.get('results', [])[:3]
        headlines = [article['title'] for article in articles]
        return "Here are the top headlines: " + " | ".join(headlines)
    except:
        return "Unable to fetch news at the moment."
