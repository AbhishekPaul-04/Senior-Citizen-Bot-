import requests
from api_keys.api_keys import OPENWEATHER_API_KEY

def get_weather(city='Delhi'):
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHER_API_KEY}&units=metric"
        response = requests.get(url).json()
        temp = response['main']['temp']
        desc = response['weather'][0]['description']
        return f"The temperature in {city} is {temp}°C with {desc}."
    except:
        return "Unable to fetch weather information right now."
