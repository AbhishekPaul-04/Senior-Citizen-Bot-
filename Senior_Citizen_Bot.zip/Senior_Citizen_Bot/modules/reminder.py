import json
import os
from datetime import datetime

reminder_file = "reminders/reminders.json"

def load_reminders():
    if os.path.exists(reminder_file):
        with open(reminder_file, "r") as f:
            return json.load(f)
    return {}

def save_reminders(reminders):
    with open(reminder_file, "w") as f:
        json.dump(reminders, f)

def add_reminder(text):
    reminders = load_reminders()
    now = datetime.now()
    key = now.strftime("%Y-%m-%d %H:%M:%S")
    reminders[key] = text
    save_reminders(reminders)
    return "Reminder added."

def check_reminders():
    # Placeholder for later scheduling implementation
    pass
