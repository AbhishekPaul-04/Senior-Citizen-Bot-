# Senior Citizen Voice Assistant Bot (Enhanced)

## 🔹 Overview
This is a GUI-based, bilingual (Hindi + English), voice-controlled assistant designed for senior citizens. It works **both online and offline** and includes features like:
- Voice chat (STT + TTS)
- Live weather updates
- News headlines
- Wikipedia search
- Time, date, and day support
- Medicine reminders
- Simple chatbot fallback (ChatGPT-style using free APIs or offline rules)

---

## ✅ Requirements
- Python 3.8+
- `pip install -r requirements.txt`

---

## 📦 Setup Steps
1. Clone or extract the ZIP.
2. Add your free API keys to `api_keys/api_keys.py`
3. Run the main bot:
```bash
python senior_citizen_bot.py
```

---

## 📁 File Structure
```
senior_citizen_bot_plus/
│
├── senior_citizen_bot.py          # Main launcher
├── requirements.txt
├── README.md
├── api_keys/
│   └── api_keys.py                # Your API keys go here
├── modules/
│   ├── weather.py
│   ├── news.py
│   ├── wiki.py
│   ├── reminder.py
│   └── fallback_chat.py
├── assets/
│   └── icon.png                   # Optional GUI assets
└── reminders/
    └── reminders.json            # Stores reminders
```

---

## 🗝️ Free APIs Used
- **OpenWeatherMap** – for live weather
- **NewsData.io** – for news headlines
- **Wikipedia** – for general questions

---

## 👵 Specially Designed For:
- Elderly users with simple GUI
- Voice-first users (mic input, audio output)
- Indian bilingual usage

---


---

## 🔑 How to Setup API Keys

1. Go to [OpenWeatherMap](https://openweathermap.org/api), create a free account and get your API key.
2. Go to [NewsData.io](https://newsdata.io/), create a free account and get your API key.
3. Open the file: `api_keys/api_keys.py`
4. Paste your keys like this:

```python
OPENWEATHER_API_KEY = "your_openweathermap_api_key"
NEWSDATA_API_KEY = "your_newsdata_api_key"
```

That's it! You're ready to go.
