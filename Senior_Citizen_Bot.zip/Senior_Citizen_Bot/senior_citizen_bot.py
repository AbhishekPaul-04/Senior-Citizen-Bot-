import tkinter as tk
import speech_recognition as sr
import pyttsx3
import datetime
from modules.weather import get_weather
from modules.news import get_news
from modules.wiki import ask_wikipedia
from modules.fallback_chat import simple_chat
from modules.ai_chat import ai_chat
from modules.reminder import check_reminders, add_reminder
import threading

engine = pyttsx3.init()
engine.setProperty('rate', 150)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        try:
            audio = r.listen(source, timeout=5)
            query = r.recognize_google(audio, language='en-IN')
            return query.lower()
        except:
            return ""

def respond_to_query(query):
    if "weather" in query:
        words = query.split()
        for i in range(len(words)):
            if words[i] in ["in", "at", "of"] and i + 1 < len(words):
                city = words[i + 1].capitalize()
                return get_weather(city)
        return get_weather("Delhi")
    elif "news" in query:
        return get_news()
    elif "time" in query:
        return datetime.datetime.now().strftime("It's %I:%M %p")
    elif "date" in query:
        return datetime.datetime.now().strftime("Today is %d %B %Y")
    elif "day" in query:
        return datetime.datetime.now().strftime("Today is %A")
    elif "remind" in query:
        response = add_reminder(query)
        return response
    else:
        return ask_wikipedia(query) or simple_chat(query)

def handle_voice():
    user_input = listen()
    if not user_input:
        result.set("Sorry, I didn't catch that.")
        speak("Sorry, I didn't catch that.")
        return
    result.set("You: " + user_input)
    response = respond_to_query(user_input)
    result.set("Bot: " + response)
    speak(response)

def start_voice_thread():
    threading.Thread(target=handle_voice).start()

# GUI
root = tk.Tk()
root.title("Senior Citizen Voice Assistant")
root.geometry("500x300")

tk.Label(root, text="Senior Citizen Assistant", font=("Arial", 18)).pack(pady=10)

result = tk.StringVar()
result.set("Press the button and speak...")

tk.Label(root, textvariable=result, wraplength=450, font=("Arial", 12)).pack(pady=20)
tk.Button(root, text="🎤 Speak", font=("Arial", 14), command=start_voice_thread).pack()

check_reminders()

root.mainloop()
